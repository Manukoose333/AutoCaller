# AutoCaller

An Android application that periodically places phone calls to a configured number using a Foreground Service, built with Kotlin and Jetpack Compose.

---

## Features

- 📞 **Automatic periodic calling** – dials a number at a configurable interval (1–60 minutes)
- 🔄 **Smart scheduling** – skips a call if one is already in progress; waits for an idle line
- 💾 **Persistent settings** – phone number, interval, and running state are saved via DataStore so they survive app restarts and device reboots
- 🔔 **Foreground Service** – keeps running in the background with an ongoing notification and a quick-stop action
- ⚡ **AlarmManager scheduling** – uses `setExactAndAllowWhileIdle` to fire even in Doze mode
- 🔃 **Boot-safe** – `BootReceiver` restarts the service after a device reboot if it was active
- 🎨 **Material 3 UI** – adaptive colour scheme, animated status banner, slider-based interval picker

---

## Architecture

```
com.autocaller/
├── AutoCallerApp.kt          # Application – creates notification channel
├── MainActivity.kt           # Single-activity host
│
├── data/
│   └── SettingsRepository.kt # DataStore Preferences repository
│
├── service/
│   ├── AutoCallerService.kt  # Foreground Service + scheduling logic
│   ├── AlarmReceiver.kt      # BroadcastReceiver for AlarmManager ticks
│   └── BootReceiver.kt       # BroadcastReceiver for BOOT_COMPLETED
│
├── ui/
│   ├── screens/
│   │   └── MainScreen.kt     # Compose UI
│   └── theme/
│       ├── Color.kt
│       ├── Theme.kt
│       └── Type.kt
│
└── viewmodel/
    └── MainViewModel.kt      # MVVM ViewModel
```

---

## Requirements

| Tool | Version |
|------|---------|
| Android Studio | Ladybug (2024.2) or newer |
| Gradle | 8.9 |
| Android Gradle Plugin | 8.7.x |
| Kotlin | 2.0.21 |
| Minimum SDK | 26 (Android 8.0 Oreo) |
| Target / Compile SDK | 35 (Android 15) |

---

## Build & Run

### 1 – Clone / download the project

```bash
git clone <repo-url>
cd AutoCaller
```

### 2 – Open in Android Studio

`File → Open` and select the `AutoCaller` directory.

### 3 – Sync Gradle

Android Studio will prompt you to sync. Click **Sync Now**.  
If it doesn't, use `File → Sync Project with Gradle Files`.

### 4 – Run on a device or emulator

```
Run → Run 'app'   (Shift+F10)
```

> **Physical device recommended** – the emulator does not support actual phone calls.  
> Enable **Developer Options → USB Debugging** on your device.

---

## Permissions explained

| Permission | Why it's needed |
|------------|----------------|
| `CALL_PHONE` | Place calls without the dialler UI |
| `READ_PHONE_STATE` | Detect if a call is already active |
| `FOREGROUND_SERVICE` | Run a foreground service |
| `FOREGROUND_SERVICE_PHONE_CALL` | Required on Android 14+ for phone-call foreground services |
| `SCHEDULE_EXACT_ALARM` / `USE_EXACT_ALARM` | Fire alarms precisely in Doze mode |
| `WAKE_LOCK` | Keep the CPU awake during the alarm callback |
| `POST_NOTIFICATIONS` | Show the ongoing notification (Android 13+) |
| `RECEIVE_BOOT_COMPLETED` | Restart the service after reboot |

---

## Android 12+ – Exact Alarm permission

On Android 12 (API 31) and 13 (API 32), the user must grant **"Alarms & Reminders"** permission manually:

`Settings → Apps → AutoCaller → Alarms & Reminders → Allow`

On Android 13+ (API 33+) the app declares `USE_EXACT_ALARM`, which grants this automatically for apps that qualify (calling / reminder apps). If your device rejects this at install time, the app falls back to inexact alarms, which may fire a few minutes late.

---

## How it works (flow)

```
User taps Start
    └─► Request CALL_PHONE permission (if not granted)
        └─► MainViewModel.startCalling()
            └─► AutoCallerService.ACTION_START
                ├─ startForeground() → shows notification
                ├─ DataStore: isRunning = true
                ├─ scheduleNextAlarm(intervalMinutes)
                └─ attemptCall() ← first call immediately

AlarmManager fires after <interval> minutes
    └─► AlarmReceiver.onReceive()
        └─► AutoCallerService.ACTION_CALL_TICK
            ├─ if (telephony.callState == IDLE) → ACTION_CALL
            └─ scheduleNextAlarm() ← reschedule

User taps Stop  (or notification action)
    └─► AutoCallerService.ACTION_STOP
        ├─ cancelAlarm()
        ├─ DataStore: isRunning = false
        └─ stopForeground() + stopSelf()
```

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Calls don't fire on time | Grant "Alarms & Reminders" in system settings |
| App crashes on start | Check Logcat for `CALL_PHONE` `SecurityException`; grant the permission manually in App Info |
| Service stops after screen off | Disable battery optimisation for AutoCaller in `Settings → Battery` |
| No notification visible | Grant notification permission (Android 13+) |

---

## License

MIT – free to use and modify.
