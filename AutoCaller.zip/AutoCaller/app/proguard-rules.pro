# Add project specific ProGuard rules here.
# For more details, see:
#   http://developer.android.com/guide/developing/tools/proguard.html

# Keep DataStore classes
-keep class androidx.datastore.** { *; }

# Keep our service and receiver classes (referenced in manifest)
-keep class com.autocaller.service.** { *; }
-keep class com.autocaller.AutoCallerApp { *; }
