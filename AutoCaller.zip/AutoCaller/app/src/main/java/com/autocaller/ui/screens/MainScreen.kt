package com.autocaller.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.autocaller.ui.theme.StatusRunning
import com.autocaller.ui.theme.StatusStopped
import com.autocaller.viewmodel.MainViewModel

/**
 * MainScreen – the single screen of AutoCaller.
 *
 * Layout (top → bottom):
 * 1. Status banner (running / stopped)
 * 2. Phone-number input field
 * 3. Interval slider + label
 * 4. Start / Stop action buttons
 * 5. Usage note card
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel = viewModel()
) {
    val context = LocalContext.current

    // ─── Observe ViewModel state ──────────────────────────────────────────────
    val phoneNumber    by viewModel.phoneNumber.collectAsStateWithLifecycle()
    val intervalMinutes by viewModel.intervalMinutes.collectAsStateWithLifecycle()
    val isRunning      by viewModel.isRunning.collectAsStateWithLifecycle()
    val errorMessage   by viewModel.errorMessage.collectAsStateWithLifecycle()

    // ─── Permission launchers ─────────────────────────────────────────────────

    // CALL_PHONE – primary permission, required before starting.
    val callPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.startCalling()
        // If denied, the user will see the "Start" button is disabled until the
        // permission is granted via system settings.
    }

    // POST_NOTIFICATIONS – only needed on Android 13+.
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* We proceed regardless; notifications are non-critical. */ }

    // Request notification permission once on first composition (Android 13+).
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Helper: returns true if CALL_PHONE is already granted.
    val hasCallPermission: Boolean
        get() = ContextCompat.checkSelfPermission(
            context, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

    // ─── Error snackbar ───────────────────────────────────────────────────────
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    // ─── UI ───────────────────────────────────────────────────────────────────
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "AutoCaller",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            // ── 1. Status Banner ─────────────────────────────────────────────
            StatusBanner(isRunning = isRunning)

            // ── 2. Phone Number Input ────────────────────────────────────────
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = viewModel::onPhoneNumberChange,
                label = { Text("Phone Number") },
                placeholder = { Text("+1 555 000 0000") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = "Phone"
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                enabled = !isRunning,
                modifier = Modifier.fillMaxWidth(),
                supportingText = {
                    Text("Include country code, e.g. +91 98765 43210")
                }
            )

            // ── 3. Interval Slider ───────────────────────────────────────────
            IntervalSlider(
                value = intervalMinutes,
                onValueChange = viewModel::onIntervalChange,
                enabled = !isRunning
            )

            Spacer(modifier = Modifier.height(4.dp))

            // ── 4. Action Buttons ────────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Start button
                Button(
                    onClick = {
                        if (hasCallPermission) {
                            viewModel.startCalling()
                        } else {
                            callPermissionLauncher.launch(Manifest.permission.CALL_PHONE)
                        }
                    },
                    enabled = !isRunning,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("Start Calling", modifier = Modifier.padding(vertical = 4.dp))
                }

                // Stop button
                OutlinedButton(
                    onClick = viewModel::stopCalling,
                    enabled = isRunning,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Stop Calling", modifier = Modifier.padding(vertical = 4.dp))
                }
            }

            // ── 5. Info Card ─────────────────────────────────────────────────
            InfoCard(intervalMinutes = intervalMinutes, isRunning = isRunning)
        }
    }
}

// ─── Composable components ────────────────────────────────────────────────────

@Composable
private fun StatusBanner(isRunning: Boolean) {
    val targetColor = if (isRunning) StatusRunning else StatusStopped
    val animatedColor by animateColorAsState(
        targetValue = targetColor,
        animationSpec = tween(durationMillis = 400),
        label = "StatusColor"
    )

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = animatedColor,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Pulsing dot indicator
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(Color.White, shape = MaterialTheme.shapes.extraSmall)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = if (isRunning) "Service Running" else "Service Stopped",
                color = Color.White,
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun IntervalSlider(
    value: Int,
    onValueChange: (Int) -> Unit,
    enabled: Boolean
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Call Interval",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
            Surface(
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.secondaryContainer
            ) {
                Text(
                    text = "${value} min",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.toInt()) },
            valueRange = 1f..60f,
            steps = 58,          // steps between 1 and 60 → values 2..59
            enabled = enabled,
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("1 min", style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("60 min", style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun InfoCard(intervalMinutes: Int, isRunning: Boolean) {
    AnimatedVisibility(visible = true) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "How it works",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = buildString {
                        append("AutoCaller will place a call every ")
                        append("$intervalMinutes minute(s).")
                        append(" If a call is already in progress, it will wait until")
                        append(" the line is free before trying again.")
                        if (isRunning) {
                            append("\n\nThe service continues running in the background")
                            append(" even if you close this app.")
                        }
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
