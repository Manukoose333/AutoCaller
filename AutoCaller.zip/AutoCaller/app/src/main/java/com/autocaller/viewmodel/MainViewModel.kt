package com.autocaller.viewmodel

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.autocaller.data.SettingsRepository
import com.autocaller.service.AutoCallerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * MainViewModel – bridges the UI layer ([ui.screens.MainScreen]) with the data
 * layer ([data.SettingsRepository]) and the service layer
 * ([service.AutoCallerService]).
 *
 * Uses [AndroidViewModel] so it can safely obtain the [Application] context
 * needed to start/stop the foreground service.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SettingsRepository(application)

    // ─── Persisted state (hot flows backed by DataStore) ─────────────────────

    /** Phone number entered by the user. */
    val phoneNumber: StateFlow<String> = repository.phoneNumberFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "")

    /** Call interval in minutes. */
    val intervalMinutes: StateFlow<Int> = repository.intervalMinutesFlow
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            SettingsRepository.DEFAULT_INTERVAL
        )

    /** Whether the AutoCaller service is currently active. */
    val isRunning: StateFlow<Boolean> = repository.isRunningFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    // ─── Transient UI state ───────────────────────────────────────────────────

    /** One-shot user-visible error message (null = no error to show). */
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // ─── Event handlers ───────────────────────────────────────────────────────

    fun onPhoneNumberChange(number: String) {
        viewModelScope.launch { repository.savePhoneNumber(number) }
    }

    fun onIntervalChange(minutes: Int) {
        val clamped = minutes.coerceIn(1, 60)
        viewModelScope.launch { repository.saveIntervalMinutes(clamped) }
    }

    /**
     * Start the AutoCaller foreground service.
     *
     * Prerequisites (checked before calling):
     * - [phoneNumber] must not be blank.
     * - CALL_PHONE permission must already be granted (checked by the UI).
     */
    fun startCalling() {
        val number = phoneNumber.value
        if (number.isBlank()) {
            _errorMessage.value = "Please enter a phone number before starting."
            return
        }
        val ctx = getApplication<Application>()
        val intent = AutoCallerService.startIntent(ctx)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent)
        } else {
            ctx.startService(intent)
        }
    }

    /** Stop the AutoCaller foreground service. */
    fun stopCalling() {
        val ctx = getApplication<Application>()
        ctx.startService(AutoCallerService.stopIntent(ctx))
    }

    /** Called by the UI once it has shown the error message. */
    fun clearError() {
        _errorMessage.value = null
    }
}
