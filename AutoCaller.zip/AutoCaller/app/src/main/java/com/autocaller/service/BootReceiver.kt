package com.autocaller.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.autocaller.data.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * BootReceiver restarts the AutoCaller foreground service after a device reboot
 * if it was running when the device shut down.
 *
 * Registered for BOOT_COMPLETED and QUICKBOOT_POWERON (HTC/some OEMs).
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON") return

        Log.d(TAG, "Boot completed received")

        // goAsync() keeps the BroadcastReceiver alive while we read DataStore.
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repository = SettingsRepository(context)
                val wasRunning = repository.isRunningFlow.first()
                if (wasRunning) {
                    Log.i(TAG, "Service was running before reboot – restarting")
                    val serviceIntent = AutoCallerService.startIntent(context)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(serviceIntent)
                    } else {
                        context.startService(serviceIntent)
                    }
                } else {
                    Log.d(TAG, "Service was not running – nothing to do")
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}
