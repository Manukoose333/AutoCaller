package com.autocaller.ui.theme

import androidx.compose.ui.graphics.Color

// ── Light scheme ────────────────────────────────────────────────────────────
val md_theme_light_primary            = Color(0xFF3B4BC8)   // deep indigo
val md_theme_light_onPrimary          = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer   = Color(0xFFDEE0FF)
val md_theme_light_onPrimaryContainer = Color(0xFF00068C)
val md_theme_light_secondary          = Color(0xFF00796B)   // teal accent
val md_theme_light_onSecondary        = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFB2DFDB)
val md_theme_light_onSecondaryContainer = Color(0xFF002019)
val md_theme_light_tertiary           = Color(0xFF6650A4)
val md_theme_light_onTertiary         = Color(0xFFFFFFFF)
val md_theme_light_error              = Color(0xFFBA1A1A)
val md_theme_light_onError            = Color(0xFFFFFFFF)
val md_theme_light_background         = Color(0xFFFBFBFF)
val md_theme_light_onBackground       = Color(0xFF1A1B21)
val md_theme_light_surface            = Color(0xFFFBFBFF)
val md_theme_light_onSurface          = Color(0xFF1A1B21)
val md_theme_light_surfaceVariant     = Color(0xFFE3E1EC)
val md_theme_light_onSurfaceVariant   = Color(0xFF46464F)
val md_theme_light_outline            = Color(0xFF777680)

// ── Dark scheme ─────────────────────────────────────────────────────────────
val md_theme_dark_primary             = Color(0xFFBAC3FF)
val md_theme_dark_onPrimary           = Color(0xFF06149A)
val md_theme_dark_primaryContainer    = Color(0xFF2130B1)
val md_theme_dark_onPrimaryContainer  = Color(0xFFDEE0FF)
val md_theme_dark_secondary           = Color(0xFF80CBC4)
val md_theme_dark_onSecondary         = Color(0xFF003732)
val md_theme_dark_secondaryContainer  = Color(0xFF004D45)
val md_theme_dark_onSecondaryContainer = Color(0xFFB2DFDB)
val md_theme_dark_tertiary            = Color(0xFFCFBCFF)
val md_theme_dark_onTertiary          = Color(0xFF381E72)
val md_theme_dark_error               = Color(0xFFFFB4AB)
val md_theme_dark_onError             = Color(0xFF690005)
val md_theme_dark_background          = Color(0xFF1A1B21)
val md_theme_dark_onBackground        = Color(0xFFE4E1E6)
val md_theme_dark_surface             = Color(0xFF1A1B21)
val md_theme_dark_onSurface           = Color(0xFFE4E1E6)
val md_theme_dark_surfaceVariant      = Color(0xFF46464F)
val md_theme_dark_onSurfaceVariant    = Color(0xFFC7C5D0)
val md_theme_dark_outline             = Color(0xFF918F9A)

// ── Semantic aliases used in UI ──────────────────────────────────────────────
val StatusRunning = Color(0xFF2E7D32)   // green
val StatusStopped = Color(0xFF616161)   // grey
