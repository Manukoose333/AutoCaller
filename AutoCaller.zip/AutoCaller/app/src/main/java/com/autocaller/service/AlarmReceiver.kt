package com.autocaller.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

/**
 * AlarmReceiver receives the periodic alarm broadcasts from [AlarmManager] and
 * forwards them to [AutoCallerService] as [AutoCallerService.ACTION_CALL_TICK].
 *
 * Using a BroadcastReceiver + startForegroundService ensures the service can be
 * woken up even if the process was killed between alarm intervals.
 */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.d(TAG, "Alarm received: ${intent.action}")

        if (intent.action == AutoCallerService.ACTION_CALL_TICK) {
            val serviceIntent = Intent(context, AutoCallerService::class.java).apply {
                action = AutoCallerService.ACTION_CALL_TICK
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }

    companion object {
        private const val TAG = "AlarmReceiver"
    }
}
