package com.autocaller

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

/**
 * Application subclass.
 *
 * Responsibilities:
 * - Create the notification channel used by [service.AutoCallerService] before
 *   any service or activity tries to post to it (required on API 26+).
 */
class AutoCallerApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AutoCaller Service",
                NotificationManager.IMPORTANCE_LOW          // silent but visible
            ).apply {
                description = "Ongoing notification while AutoCaller is active"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "autocaller_channel"
        const val NOTIFICATION_ID = 1001
    }
}
