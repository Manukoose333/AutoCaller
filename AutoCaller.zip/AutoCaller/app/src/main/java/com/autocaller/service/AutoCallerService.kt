package com.autocaller.service

import android.app.AlarmManager
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.util.Log
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.autocaller.AutoCallerApp
import com.autocaller.MainActivity
import com.autocaller.data.SettingsRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import androidx.core.app.NotificationCompat
import com.autocaller.R

/**
 * AutoCallerService – Foreground Service that manages the periodic call loop.
 *
 * Architecture:
 * - The service is started with [ACTION_START] or [ACTION_STOP] intents.
 * - On start, it schedules a repeating alarm via [AlarmManager] so the call
 *   attempt fires even if the process is killed between intervals.
 * - On each alarm tick (delivered via [AlarmReceiver] → [ACTION_CALL_TICK]),
 *   the service checks whether a call is already in progress via
 *   [TelephonyManager] before dialling.
 * - All settings are read from [SettingsRepository] (DataStore).
 */
class AutoCallerService : LifecycleService() {

    private lateinit var repository: SettingsRepository
    private lateinit var alarmManager: AlarmManager
    private lateinit var telephonyManager: TelephonyManager

    override fun onCreate() {
        super.onCreate()
        repository = SettingsRepository(applicationContext)
        alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        Log.d(TAG, "Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_START -> handleStart()
            ACTION_STOP  -> handleStop()
            ACTION_CALL_TICK -> handleCallTick()
            else -> Log.w(TAG, "Unknown action: ${intent?.action}")
        }

        // START_STICKY so Android recreates the service if it is killed,
        // supplying a null intent so we don't re-execute an old action.
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    // ─── Action handlers ─────────────────────────────────────────────────────

    private fun handleStart() {
        Log.d(TAG, "handleStart()")
        startForeground(AutoCallerApp.NOTIFICATION_ID, buildNotification("AutoCaller is running"))

        lifecycleScope.launch {
            // Persist running state.
            repository.saveIsRunning(true)

            val intervalMinutes = repository.intervalMinutesFlow.first()
            scheduleNextAlarm(intervalMinutes)

            // Fire the first call attempt immediately.
            attemptCall()
        }
    }

    private fun handleStop() {
        Log.d(TAG, "handleStop()")
        lifecycleScope.launch {
            repository.saveIsRunning(false)
        }
        cancelAlarm()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun handleCallTick() {
        Log.d(TAG, "handleCallTick()")
        lifecycleScope.launch {
            val isRunning = repository.isRunningFlow.first()
            if (!isRunning) {
                Log.d(TAG, "Service marked as stopped – ignoring tick")
                return@launch
            }
            attemptCall()
            // Re-schedule next alarm.
            val intervalMinutes = repository.intervalMinutesFlow.first()
            scheduleNextAlarm(intervalMinutes)
        }
    }

    // ─── Call logic ──────────────────────────────────────────────────────────

    /**
     * Attempt to place a call. Skips if a call is already active.
     *
     * Note: CALL_PHONE permission must already be granted before this is called;
     * the ViewModel / UI handles runtime permission requests.
     */
    private suspend fun attemptCall() {
        val phoneNumber = repository.phoneNumberFlow.first()
        if (phoneNumber.isBlank()) {
            Log.w(TAG, "No phone number configured – skipping call attempt")
            return
        }

        // Check whether a call is already in progress.
        val callState = telephonyManager.callState
        if (callState != TelephonyManager.CALL_STATE_IDLE) {
            Log.d(TAG, "Call already in progress (state=$callState) – skipping")
            return
        }

        Log.i(TAG, "Placing call to $phoneNumber")
        try {
            val callIntent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:${Uri.encode(phoneNumber)}")
                // Ensure the intent launches outside the task stack so it doesn't
                // bring AutoCaller to the foreground on every call.
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(callIntent)
        } catch (e: SecurityException) {
            Log.e(TAG, "CALL_PHONE permission not granted", e)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to place call", e)
        }
    }

    // ─── AlarmManager ────────────────────────────────────────────────────────

    private fun scheduleNextAlarm(intervalMinutes: Int) {
        val triggerAtMillis = SystemClock.elapsedRealtime() +
                intervalMinutes * 60_000L

        val pendingIntent = alarmPendingIntent()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                // Fall back to inexact alarm if user has not granted exact-alarm permission.
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        } else {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                triggerAtMillis,
                pendingIntent
            )
        }
        Log.d(TAG, "Next alarm in $intervalMinutes minute(s)")
    }

    private fun cancelAlarm() {
        alarmManager.cancel(alarmPendingIntent())
        Log.d(TAG, "Alarm cancelled")
    }

    private fun alarmPendingIntent(): PendingIntent {
        val intent = Intent(this, AlarmReceiver::class.java).apply {
            action = ACTION_CALL_TICK
        }
        return PendingIntent.getBroadcast(
            this,
            REQUEST_CODE_ALARM,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    // ─── Notification ────────────────────────────────────────────────────────

    private fun buildNotification(contentText: String): Notification {
        // Tapping the notification opens MainActivity.
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPending = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // "Stop" action directly from the notification shade.
        val stopIntent = Intent(this, AutoCallerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, AutoCallerApp.CHANNEL_ID)
            .setContentTitle("AutoCaller")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(openAppPending)
            .addAction(0, "Stop", stopPending)
            .build()
    }

    // ─── Constants ───────────────────────────────────────────────────────────

    companion object {
        private const val TAG = "AutoCallerService"
        private const val REQUEST_CODE_ALARM = 42

        const val ACTION_START     = "com.autocaller.ACTION_START"
        const val ACTION_STOP      = "com.autocaller.ACTION_STOP"
        const val ACTION_CALL_TICK = "com.autocaller.ACTION_CALL_TICK"

        /** Convenience factory for the START intent. */
        fun startIntent(context: Context) =
            Intent(context, AutoCallerService::class.java).apply { action = ACTION_START }

        /** Convenience factory for the STOP intent. */
        fun stopIntent(context: Context) =
            Intent(context, AutoCallerService::class.java).apply { action = ACTION_STOP }
    }
}
